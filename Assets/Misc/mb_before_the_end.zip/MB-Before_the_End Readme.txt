MB-Before_the_End Horror, Scratched Font by ModBlackmoon [handwritten + Photoshop].
Incl. English, European and Cyrillic letters and Numbers.

Free for personal and commercial use. No modify!
Sharing this font on the other web-sites is forbidden.

Designed: August 2010.
Author: ModBlackmoon
WEB: modblackmoon.narod.ru / modblackmoon.deviantart.com